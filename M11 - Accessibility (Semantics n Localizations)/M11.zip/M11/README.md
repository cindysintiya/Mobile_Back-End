pubspec.yaml : add assets
gradle-wrapper.properties : distiburtionUrl=.../gradle-7.6-all.zip